clear
g++ *.cpp -Wall -Wextra -Wno-conversion -pedantic -std=c++20 -o main.a
./main.a
